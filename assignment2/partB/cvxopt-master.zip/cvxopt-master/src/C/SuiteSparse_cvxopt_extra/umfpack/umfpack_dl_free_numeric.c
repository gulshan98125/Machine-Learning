#define DLONG

#include "umfpack_free_numeric.c"
