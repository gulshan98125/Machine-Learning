#define DLONG

#include "umfpack_numeric.c"
