#define ZLONG

#include "umf_set_stats.c"
