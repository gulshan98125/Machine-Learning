#define ZLONG

#include "umf_assemble.c"
