#define DLONG

#include "umf_colamd.c"
