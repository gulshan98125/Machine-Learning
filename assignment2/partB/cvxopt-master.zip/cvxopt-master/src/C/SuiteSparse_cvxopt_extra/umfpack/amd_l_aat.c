#define DLONG

#include "amd_aat.c"
