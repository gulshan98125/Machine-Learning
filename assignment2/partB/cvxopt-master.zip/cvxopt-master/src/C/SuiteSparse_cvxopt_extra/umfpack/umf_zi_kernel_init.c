#define ZINT
#include "umf_kernel_init.c"
